全表 CSV 导出（2026-11-23 · 后端 v2 数据模型）
============================================

来源：PriceLens 服务器 SQLite（v2 表结构，24 张表）一次性全量导出。库由当前真实数据
（server/data/offers.csv 97,299 行 + 空 sales + config.json）经 2026-11-23 重构后的
服务器引擎派生生成。字段定义与《PriceLens-数据方案-表结构与链接关系-稳定版-2026-11-22.xlsx》
一一对应（表间 join 键见该文件「链接关系」页签；指标口径见
《PriceLens-指标映射方案-事实到指标与指标到前端-2026-11-23.xlsx》）。

格式：utf-8-sig（Excel 双击直开不乱码）+ CRLF 换行 + RFC4180 引号转义。
     空值 = 空串。金额/汇率为数值原文（无千分位）。

行数快照（合计 209,742 行）
--------
【源层 ODS】原表有的
ods_offer             97,299   offer 底表原样（29 规范列 + extra_json）
ods_psi                    0   PSI 销量源未接（接入后自动生成销量事实）

【匹配配置层 MAP】我们加的
map_product             9,826   统一匹配表（本快照全部为引擎自动派生的 offer 侧行，
                               match_status = offer_only；接入 PSI 并回填 xlsx 后
                               才出现 matched / psi_only）
map_competitor              0   ┐ 三张配置表由 data/config_tables.xlsx 填充。本快照
map_price_band              0   │ 取自未放该文件的库，所以只有表头；部署包已预置该
map_promo                   0   ┘ xlsx，首次启动后即有数据

【维表层 DIM】每个筛选器一张
dim_category                6
dim_brand                  27   我司 1 / 竞品 26
dim_series                211
dim_model                 564   我司 102 / 竞品 462
dim_sku                 1,263
dim_platform               55
dim_store_type              3   1P / 3P / 独立站
dim_shop                3,380
dim_region                 29
dim_time                   27   202619–202645
dim_fx                    112   22 币种 × 月
dim_promo                  66   ┐ 前端契约形态照存（内容来自 config.json）
dim_benchmark             950   │
dim_tier                    1   ┘

【事实层 FACT】
fact_price              95,922   周 × 国家 × 平台 × 店铺类型 × 店铺 × SKU
                               （25 国 / 1,263 SKU；双价族，官方族为预留、全空）
fact_sales                   0   周销量事实（PSI 源接入后物理化）

【其他】
cfg_kv                      0   预留位（配置走 data/config.json 与 config_tables.xlsx）
meta_import                 1   本次派生批次

再生成方式（数据更新后重导）
--------
    python3 scripts/export_all_tables_csv.py <pricelens.db> <输出目录>
（脚本按库里实际存在的表导出，表结构变更不用改脚本。）

这些 CSV 是「当前数据集的快照」，供内部核对 / 评审 / 数仓比对用；
日常运行数据仍以服务器 data/ 文件夹（offers.csv + sales.csv → 自动派生）为准。
